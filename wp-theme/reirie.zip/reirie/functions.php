<?php
/**
 * REIRIE Theme - functions.php
 *
 * @package REIRIE
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'REIRIE_VERSION', '1.0.0' );
define( 'REIRIE_DIR', get_template_directory() );
define( 'REIRIE_URI', get_template_directory_uri() );

/* ==========================================================
   テーマセットアップ
========================================================== */
function reirie_setup() {
	load_theme_textdomain( 'reirie', REIRIE_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 240,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );

	register_nav_menus( array(
		'primary' => __( 'グローバルナビゲーション', 'reirie' ),
		'footer'  => __( 'フッターメニュー', 'reirie' ),
	) );

	// アイキャッチ画像のサイズ
	add_image_size( 'reirie-jacket', 800, 800, true );
	add_image_size( 'reirie-thumb-16-9', 800, 450, true );
	add_image_size( 'reirie-member', 800, 1000, true );
}
add_action( 'after_setup_theme', 'reirie_setup' );

/* ==========================================================
   CSS / JS の読み込み
========================================================== */
function reirie_enqueue_assets() {
	// Google Fonts
	wp_enqueue_style(
		'reirie-google-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600;700&family=Noto+Sans+JP:wght@300;400;500;700&family=Shrikhand&display=swap',
		array(),
		null
	);

	// メインCSS
	wp_enqueue_style(
		'reirie-main',
		REIRIE_URI . '/assets/css/main.css',
		array( 'reirie-google-fonts' ),
		REIRIE_VERSION
	);

	// テーマ識別用style.css（必須）
	wp_enqueue_style(
		'reirie-style',
		get_stylesheet_uri(),
		array( 'reirie-main' ),
		REIRIE_VERSION
	);

	// パーティクル
	wp_enqueue_script(
		'reirie-particles',
		REIRIE_URI . '/assets/js/particles.js',
		array(),
		REIRIE_VERSION,
		true
	);

	// メインJS
	wp_enqueue_script(
		'reirie-main',
		REIRIE_URI . '/assets/js/main.js',
		array(),
		REIRIE_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'reirie_enqueue_assets' );

/* ==========================================================
   各機能ファイルの読み込み
========================================================== */
require_once REIRIE_DIR . '/inc/post-types.php';
require_once REIRIE_DIR . '/inc/customizer.php';
require_once REIRIE_DIR . '/inc/template-functions.php';
require_once REIRIE_DIR . '/inc/acf-fallback.php';
require_once REIRIE_DIR . '/inc/admin-notices.php';
require_once REIRIE_DIR . '/inc/admin-dashboard.php';
require_once REIRIE_DIR . '/inc/contact-form.php';

/* ==========================================================
   ACF JSON の保存先 / 読み込み元（テーマ内で同期）
========================================================== */
function reirie_acf_json_save_point( $path ) {
	return REIRIE_DIR . '/acf-json';
}
add_filter( 'acf/settings/save_json', 'reirie_acf_json_save_point' );

function reirie_acf_json_load_point( $paths ) {
	$paths[] = REIRIE_DIR . '/acf-json';
	return $paths;
}
add_filter( 'acf/settings/load_json', 'reirie_acf_json_load_point' );

/* ==========================================================
   抜粋の文字数制御
========================================================== */
function reirie_excerpt_length() { return 60; }
add_filter( 'excerpt_length', 'reirie_excerpt_length', 999 );

function reirie_excerpt_more() { return '…'; }
add_filter( 'excerpt_more', 'reirie_excerpt_more' );

/* ==========================================================
   body_class に判別用クラスを追加
========================================================== */
function reirie_body_class( $classes ) {
	if ( is_front_page() ) $classes[] = 'is-front';
	if ( is_singular() )   $classes[] = 'is-singular';
	return $classes;
}
add_filter( 'body_class', 'reirie_body_class' );
