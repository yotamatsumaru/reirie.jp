<?php
/**
 * Hero Section
 *
 * @package REIRIE
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$hero_bg_type   = get_theme_mod( 'reirie_hero_bg_type', 'video' );
$hero_video     = get_theme_mod( 'reirie_hero_video', REIRIE_URI . '/assets/video/hero.mp4' );
$hero_image     = get_theme_mod( 'reirie_hero_image', '' );
$hero_overlay   = (int) get_theme_mod( 'reirie_hero_overlay', 30 );
$hero_sub       = get_theme_mod( 'reirie_hero_sub', '2-girls IDOL UNIT' );
$hero_title     = get_theme_mod( 'reirie_hero_title', 'REIRIE' );
$hero_title_jp  = get_theme_mod( 'reirie_hero_title_jp', 'レイリエ' );
$hero_catch     = get_theme_mod( 'reirie_hero_catch', 'ふたりで描く、きらめきの世界。' );
$cta1_label     = get_theme_mod( 'reirie_hero_cta1_label', '' );
$cta1_url       = get_theme_mod( 'reirie_hero_cta1_url', '' );
$cta2_label     = get_theme_mod( 'reirie_hero_cta2_label', '' );
$cta2_url       = get_theme_mod( 'reirie_hero_cta2_url', '' );
$marquee_text   = get_theme_mod( 'reirie_marquee_text', '★ REIRIE OFFICIAL SITE ★ NEW SINGLE OUT NOW ★ 1st ONE-MAN LIVE 2026.07.20 ★' );
$marquee_show   = (int) get_theme_mod( 'reirie_marquee_show', 1 );
$overlay_alpha  = max( 0, min( 80, $hero_overlay ) ) / 100;
?>

<section class="hero" id="hero">
  <div class="hero__video-wrap">
    <?php if ( $hero_bg_type === 'image' && $hero_image ) : ?>
      <div class="hero__image" style="background-image:url('<?php echo esc_url( $hero_image ); ?>');background-size:cover;background-position:center;width:100%;height:100%;position:absolute;inset:0;"></div>
    <?php else : ?>
      <video class="hero__video" autoplay muted loop playsinline <?php echo $hero_image ? 'poster="' . esc_url( $hero_image ) . '"' : ''; ?>>
        <source src="<?php echo esc_url( $hero_video ); ?>" type="video/mp4">
      </video>
    <?php endif; ?>
    <div class="hero__overlay" style="background:rgba(20,10,30,<?php echo esc_attr( $overlay_alpha ); ?>);"></div>
    <div class="hero__grain"></div>
  </div>

  <div class="hero__content">
    <p class="hero__sub"><?php echo esc_html( $hero_sub ); ?></p>
    <h1 class="hero__title">
      <span class="hero__title-main"><?php echo esc_html( $hero_title ); ?></span>
      <span class="hero__title-jp"><?php echo esc_html( $hero_title_jp ); ?></span>
    </h1>
    <p class="hero__catch">
      <span>“</span>
      <?php echo esc_html( $hero_catch ); ?>
      <span>”</span>
    </p>

    <?php if ( $cta1_label || $cta2_label ) : ?>
      <div class="hero__cta">
        <?php if ( $cta1_label ) : ?>
          <a class="hero__btn hero__btn--primary" href="<?php echo esc_url( $cta1_url ?: '#' ); ?>"><?php echo esc_html( $cta1_label ); ?></a>
        <?php endif; ?>
        <?php if ( $cta2_label ) : ?>
          <a class="hero__btn hero__btn--ghost" href="<?php echo esc_url( $cta2_url ?: '#' ); ?>"><?php echo esc_html( $cta2_label ); ?></a>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <a href="#news" class="hero__scroll">
      <span>SCROLL</span>
      <span class="hero__scroll-line"></span>
    </a>
  </div>

  <?php if ( $marquee_show && $marquee_text ) : ?>
    <div class="hero__marquee">
      <div class="marquee-track">
        <span><?php echo esc_html( $marquee_text ); ?> </span>
        <span><?php echo esc_html( $marquee_text ); ?> </span>
      </div>
    </div>
  <?php endif; ?>
</section>
