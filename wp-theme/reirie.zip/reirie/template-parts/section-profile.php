<?php
/**
 * Profile Section（メンバー紹介）
 *
 * @package REIRIE
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$member_query = new WP_Query( array(
	'post_type'      => 'member',
	'posts_per_page' => -1,
	'post_status'    => 'publish',
	'orderby'        => 'menu_order',
	'order'          => 'ASC',
) );
?>

<section class="section profile" id="profile">
  <div class="section__head">
    <span class="section__num">05 / Profile</span>
    <h2 class="section__title">Profile<span class="section__title-jp">プロフィール</span></h2>
  </div>

  <div class="member__grid">
    <?php if ( $member_query->have_posts() ) :
      $i = 0;
      while ( $member_query->have_posts() ) : $member_query->the_post();
        $color       = reirie_field( 'member_color', false, '' );
        $color_cls   = reirie_field( 'member_color_class', false, ( $i === 0 ? 'color-pink' : 'color-blue' ) );
        $photo_cls   = reirie_field( 'member_photo_class', false, ( $i === 0 ? 'photo-rei' : 'photo-rie' ) );
        $initial     = reirie_field( 'member_initial', false, 'R' );
        $name_jp     = reirie_field( 'member_name_jp' );
        $catch       = reirie_field( 'member_catch' );
        $birthday    = reirie_field( 'member_birthday' );
        $blood       = reirie_field( 'member_blood' );
        $hometown    = reirie_field( 'member_hometown' );
        $height      = reirie_field( 'member_height' );
        $hobby       = reirie_field( 'member_hobby' );
        $charm       = reirie_field( 'member_charm' );
        $skill       = reirie_field( 'member_skill' );
        $message     = reirie_field( 'member_message' );
        $photo       = get_the_post_thumbnail_url( get_the_ID(), 'reirie-member' );

        // SNS
        $sns_links = array(
          'twitter'   => array( 'url' => reirie_field( 'member_sns_twitter' ),   'label' => 'X' ),
          'instagram' => array( 'url' => reirie_field( 'member_sns_instagram' ), 'label' => 'IG' ),
          'tiktok'    => array( 'url' => reirie_field( 'member_sns_tiktok' ),    'label' => 'TT' ),
          'blog'      => array( 'url' => reirie_field( 'member_sns_blog' ),      'label' => 'BLOG' ),
        );
    ?>
      <article class="member__card">
        <div class="member__photo <?php echo esc_attr( $photo_cls ); ?>"<?php echo $photo ? ' style="background-image:url(' . esc_url( $photo ) . ');background-size:cover;background-position:center;"' : ''; ?>>
          <?php if ( ! $photo ) : ?>
            <div class="member__photo-inner">
              <span class="initial"><?php echo esc_html( $initial ); ?></span>
            </div>
          <?php endif; ?>
        </div>
        <div class="member__info">
          <?php if ( $color ) : ?>
            <p class="member__color <?php echo esc_attr( $color_cls ); ?>"><?php echo esc_html( $color ); ?></p>
          <?php endif; ?>
          <h3 class="member__name">
            <span class="en"><?php the_title(); ?></span>
            <?php if ( $name_jp ) : ?><span class="ja"><?php echo esc_html( $name_jp ); ?></span><?php endif; ?>
          </h3>
          <?php if ( $catch ) : ?>
            <p class="member__catch"><?php echo esc_html( $catch ); ?></p>
          <?php endif; ?>
          <dl class="member__data">
            <?php if ( $birthday ) : ?><div><dt>Birthday</dt><dd><?php echo esc_html( $birthday ); ?></dd></div><?php endif; ?>
            <?php if ( $blood ) : ?><div><dt>Blood Type</dt><dd><?php echo esc_html( $blood ); ?></dd></div><?php endif; ?>
            <?php if ( $hometown ) : ?><div><dt>Hometown</dt><dd><?php echo esc_html( $hometown ); ?></dd></div><?php endif; ?>
            <?php if ( $height ) : ?><div><dt>Height</dt><dd><?php echo esc_html( $height ); ?></dd></div><?php endif; ?>
            <?php if ( $hobby ) : ?><div><dt>Hobby</dt><dd><?php echo esc_html( $hobby ); ?></dd></div><?php endif; ?>
            <?php if ( $charm ) : ?><div><dt>Charm Point</dt><dd><?php echo esc_html( $charm ); ?></dd></div><?php endif; ?>
            <?php if ( $skill ) : ?><div><dt>Skill</dt><dd><?php echo esc_html( $skill ); ?></dd></div><?php endif; ?>
          </dl>
          <?php if ( $message ) : ?>
            <p class="member__msg"><?php echo esc_html( $message ); ?></p>
          <?php endif; ?>

          <?php
          $has_sns = false;
          foreach ( $sns_links as $s ) { if ( ! empty( $s['url'] ) ) { $has_sns = true; break; } }
          if ( $has_sns ) : ?>
            <div class="member__sns">
              <?php foreach ( $sns_links as $key => $s ) : if ( empty( $s['url'] ) ) continue; ?>
                <a class="member__sns-link member__sns--<?php echo esc_attr( $key ); ?>" href="<?php echo esc_url( $s['url'] ); ?>" target="_blank" rel="noopener">
                  <?php echo esc_html( $s['label'] ); ?>
                </a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </article>
    <?php $i++; endwhile; wp_reset_postdata(); else : ?>

      <article class="member__card">
        <div class="member__photo photo-rei"><div class="member__photo-inner"><span class="initial">R</span></div></div>
        <div class="member__info">
          <p class="member__color color-pink">PINK</p>
          <h3 class="member__name"><span class="en">Rei</span><span class="ja">レイ</span></h3>
          <dl class="member__data">
            <div><dt>Birthday</dt><dd>9月12日</dd></div>
            <div><dt>Blood Type</dt><dd>A型</dd></div>
            <div><dt>Hometown</dt><dd>東京都</dd></div>
            <div><dt>Hobby</dt><dd>カフェ巡り / 写真</dd></div>
            <div><dt>Charm Point</dt><dd>くるんとした目</dd></div>
          </dl>
          <p class="member__msg">「いつも応援ありがとう！ふたりで最高の景色見せるね♡」</p>
        </div>
      </article>
      <article class="member__card">
        <div class="member__photo photo-rie"><div class="member__photo-inner"><span class="initial">R</span></div></div>
        <div class="member__info">
          <p class="member__color color-blue">SKY BLUE</p>
          <h3 class="member__name"><span class="en">Rie</span><span class="ja">リエ</span></h3>
          <dl class="member__data">
            <div><dt>Birthday</dt><dd>3月3日</dd></div>
            <div><dt>Blood Type</dt><dd>O型</dd></div>
            <div><dt>Hometown</dt><dd>大阪府</dd></div>
            <div><dt>Hobby</dt><dd>お菓子作り / ダンス</dd></div>
            <div><dt>Charm Point</dt><dd>えくぼ</dd></div>
          </dl>
          <p class="member__msg">「REIRIEを好きになってくれてうれしい！ずっと一緒だよ☆」</p>
        </div>
      </article>

    <?php endif; ?>
  </div>
</section>
