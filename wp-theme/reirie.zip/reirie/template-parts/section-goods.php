<?php
/**
 * Goods Section
 *
 * @package REIRIE
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$goods_query = new WP_Query( array(
	'post_type'      => 'goods',
	'posts_per_page' => 8,
	'post_status'    => 'publish',
) );
?>

<section class="section goods" id="goods">
  <div class="section__head">
    <span class="section__num">06 / Goods</span>
    <h2 class="section__title">Goods<span class="section__title-jp">グッズ</span></h2>
  </div>

  <div class="goods__grid">
    <?php if ( $goods_query->have_posts() ) :
      $i = 0;
      while ( $goods_query->have_posts() ) : $goods_query->the_post();
        $price  = reirie_field( 'goods_price' );
        $link   = reirie_field( 'goods_link', false, get_permalink() );
        $status = reirie_field( 'goods_status' );
        $thumb  = get_the_post_thumbnail_url( get_the_ID(), 'reirie-jacket' );
        $is_external = ( $link !== get_permalink() );
    ?>
      <article class="goods__item<?php echo $status === 'SOLD OUT' ? ' is-soldout' : ''; ?>">
        <a href="<?php echo esc_url( $link ); ?>"<?php echo $is_external ? ' target="_blank" rel="noopener"' : ''; ?>>
          <?php if ( $thumb ) : ?>
            <div class="goods__img" style="background-image:url('<?php echo esc_url( $thumb ); ?>');background-size:cover;background-position:center;">
              <?php if ( $status ) : ?><span class="goods__status goods__status--<?php echo esc_attr( strtolower( str_replace( ' ', '-', $status ) ) ); ?>"><?php echo esc_html( $status ); ?></span><?php endif; ?>
            </div>
          <?php else : ?>
            <div class="goods__img goods-<?php echo esc_attr( ( $i % 4 ) + 1 ); ?>">
              <?php if ( $status ) : ?><span class="goods__status goods__status--<?php echo esc_attr( strtolower( str_replace( ' ', '-', $status ) ) ); ?>"><?php echo esc_html( $status ); ?></span><?php endif; ?>
            </div>
          <?php endif; ?>
          <p class="goods__name"><?php the_title(); ?></p>
          <?php if ( $price ) : ?><p class="goods__price"><?php echo esc_html( $price ); ?></p><?php endif; ?>
        </a>
      </article>
    <?php $i++; endwhile; wp_reset_postdata(); else : ?>

      <article class="goods__item">
        <div class="goods__img goods-1"></div>
        <p class="goods__name">REIRIE ロゴT (Pink)</p>
        <p class="goods__price">¥3,800</p>
      </article>
      <article class="goods__item">
        <div class="goods__img goods-2"></div>
        <p class="goods__name">アクリルスタンド (2個セット)</p>
        <p class="goods__price">¥2,500</p>
      </article>
      <article class="goods__item">
        <div class="goods__img goods-3"></div>
        <p class="goods__name">ペンライト 2026 ver.</p>
        <p class="goods__price">¥3,200</p>
      </article>
      <article class="goods__item">
        <div class="goods__img goods-4"></div>
        <p class="goods__name">缶バッジ コンプリートセット</p>
        <p class="goods__price">¥1,800</p>
      </article>

    <?php endif; ?>
  </div>

  <div class="section__more">
    <a href="<?php echo esc_url( get_post_type_archive_link( 'goods' ) ); ?>" class="more-btn"><span>OFFICIAL STORE</span></a>
  </div>
</section>
