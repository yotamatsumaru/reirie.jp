<?php
/**
 * Discography Section
 *
 * @package REIRIE
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$disco_query = new WP_Query( array(
	'post_type'      => 'discography',
	'posts_per_page' => 6,
	'post_status'    => 'publish',
	'meta_key'       => 'disco_release_date',
	'orderby'        => 'meta_value',
	'order'          => 'DESC',
) );
?>

<section class="section discography" id="discography">
  <div class="section__head">
    <span class="section__num">03 / Discography</span>
    <h2 class="section__title">Discography<span class="section__title-jp">作品</span></h2>
  </div>

  <div class="disco__grid">
    <?php if ( $disco_query->have_posts() ) :
      $i = 0;
      while ( $disco_query->have_posts() ) : $disco_query->the_post();
        $cat        = reirie_field( 'disco_category', false, '' );
        $release    = reirie_field( 'disco_release_date' );
        $price      = reirie_field( 'disco_price' );
        $tracks_raw = reirie_field( 'disco_tracks' );
        $tracks     = $tracks_raw ? preg_split( '/\r\n|\r|\n/', $tracks_raw ) : array();
        $is_new     = reirie_field( 'disco_is_new' );
        $thumb      = get_the_post_thumbnail_url( get_the_ID(), 'reirie-jacket' );

        // 購入・配信リンク
        $links = array(
          'buy'     => array( 'url' => reirie_field( 'disco_buy_url' ),     'label' => 'BUY',     'icon' => '🛒', 'class' => 'btn-buy' ),
          'apple'   => array( 'url' => reirie_field( 'disco_apple_url' ),   'label' => 'Apple',   'icon' => '🍎', 'class' => 'btn-apple' ),
          'spotify' => array( 'url' => reirie_field( 'disco_spotify_url' ), 'label' => 'Spotify', 'icon' => '🟢', 'class' => 'btn-spotify' ),
          'youtube' => array( 'url' => reirie_field( 'disco_youtube_url' ), 'label' => 'YT Music','icon' => '▶',  'class' => 'btn-youtube' ),
          'linkco'  => array( 'url' => reirie_field( 'disco_linkco_url' ),  'label' => 'LISTEN',  'icon' => '🔗', 'class' => 'btn-linkco' ),
        );
    ?>
      <article class="disco__item">
        <div class="disco__jacket">
          <?php if ( $thumb ) : ?>
            <div class="jacket-art" style="background-image:url('<?php echo esc_url( $thumb ); ?>');background-size:cover;background-position:center;"></div>
          <?php else : ?>
            <div class="jacket-art jacket-<?php echo esc_attr( ( $i % 3 ) + 1 ); ?>">
              <span class="jacket-title"><?php the_title(); ?></span>
            </div>
          <?php endif; ?>
          <?php if ( $is_new ) : ?><span class="disco__badge">NEW</span><?php endif; ?>
        </div>
        <div class="disco__info">
          <?php if ( $cat ) : ?><span class="disco__cat"><?php echo esc_html( $cat ); ?></span><?php endif; ?>
          <h3 class="disco__title"><?php the_title(); ?></h3>
          <?php if ( $release ) : ?>
            <p class="disco__date"><?php echo esc_html( reirie_format_date( $release ) ); ?> RELEASE</p>
          <?php endif; ?>
          <?php if ( $price ) : ?>
            <p class="disco__price"><?php echo esc_html( $price ); ?></p>
          <?php endif; ?>
          <?php if ( $tracks ) : ?>
            <ul class="disco__tracks">
              <?php foreach ( $tracks as $t ) : if ( trim( $t ) === '' ) continue; ?>
                <li><?php echo esc_html( $t ); ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>

          <?php
          $has_links = false;
          foreach ( $links as $l ) { if ( ! empty( $l['url'] ) ) { $has_links = true; break; } }
          if ( $has_links ) : ?>
            <div class="disco__links">
              <?php foreach ( $links as $key => $l ) : if ( empty( $l['url'] ) ) continue; ?>
                <a href="<?php echo esc_url( $l['url'] ); ?>" class="disco__link <?php echo esc_attr( $l['class'] ); ?>" target="_blank" rel="noopener">
                  <span class="ico"><?php echo esc_html( $l['icon'] ); ?></span>
                  <span><?php echo esc_html( $l['label'] ); ?></span>
                </a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </article>
    <?php $i++; endwhile; wp_reset_postdata(); else : ?>

      <article class="disco__item">
        <div class="disco__jacket">
          <div class="jacket-art jacket-1"><span class="jacket-title">Twinkle<br>Heart</span></div>
          <span class="disco__badge">NEW</span>
        </div>
        <div class="disco__info">
          <span class="disco__cat">2nd Single</span>
          <h3 class="disco__title">Twinkle Heart</h3>
          <p class="disco__date">2026.05.20 RELEASE</p>
          <ul class="disco__tracks"><li>1. Twinkle Heart</li><li>2. シュガーリーフ</li><li>3. Twinkle Heart (Instrumental)</li></ul>
        </div>
      </article>
      <article class="disco__item">
        <div class="disco__jacket"><div class="jacket-art jacket-2"><span class="jacket-title">Bloom<br>Bloom</span></div></div>
        <div class="disco__info">
          <span class="disco__cat">1st Single</span>
          <h3 class="disco__title">Bloom Bloom</h3>
          <p class="disco__date">2026.02.14 RELEASE</p>
          <ul class="disco__tracks"><li>1. Bloom Bloom</li><li>2. キミとサクラ</li></ul>
        </div>
      </article>
      <article class="disco__item">
        <div class="disco__jacket"><div class="jacket-art jacket-3"><span class="jacket-title">Hello,<br>REIRIE</span></div></div>
        <div class="disco__info">
          <span class="disco__cat">Debut Mini Album</span>
          <h3 class="disco__title">Hello, REIRIE</h3>
          <p class="disco__date">2025.11.01 RELEASE</p>
          <ul class="disco__tracks"><li>1. Hello, World</li><li>2. ふたりのストーリー</li><li>3. Sweet Days</li></ul>
        </div>
      </article>

    <?php endif; ?>
  </div>
</section>
