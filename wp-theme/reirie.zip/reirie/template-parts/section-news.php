<?php
/**
 * News Section
 *
 * @package REIRIE
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$news_query = new WP_Query( array(
	'post_type'      => 'news',
	'posts_per_page' => 5,
	'post_status'    => 'publish',
) );
?>

<section class="section news" id="news">
  <div class="section__head">
    <span class="section__num">01 / News</span>
    <h2 class="section__title">News<span class="section__title-jp">お知らせ</span></h2>
  </div>

  <div class="news__list">
    <?php if ( $news_query->have_posts() ) : while ( $news_query->have_posts() ) : $news_query->the_post();
      $date_meta = reirie_field( 'news_date' );
      $display_date = $date_meta ? reirie_format_date( $date_meta ) : get_the_date( 'Y.m.d' );
      $external_link = reirie_field( 'news_link' );
      $link = $external_link ? $external_link : get_permalink();
    ?>
      <article class="news__item">
        <a href="<?php echo esc_url( $link ); ?>"<?php echo $external_link ? ' target="_blank" rel="noopener"' : ''; ?> class="news__link">
          <span class="news__date"><?php echo esc_html( $display_date ); ?></span>
          <span class="news__cat"><?php echo esc_html( reirie_get_news_category() ); ?></span>
          <span class="news__title"><?php the_title(); ?></span>
        </a>
      </article>
    <?php endwhile; wp_reset_postdata(); else : ?>

      <?php /* デモ用フォールバック */ ?>
      <article class="news__item"><a href="#" class="news__link">
        <span class="news__date">2026.05.08</span>
        <span class="news__cat">RELEASE</span>
        <span class="news__title">2nd Single「Twinkle Heart」5月20日リリース決定！</span>
      </a></article>
      <article class="news__item"><a href="#" class="news__link">
        <span class="news__date">2026.05.01</span>
        <span class="news__cat">LIVE</span>
        <span class="news__title">1st ONE-MAN LIVE「A Lovely Spring」開催決定のお知らせ</span>
      </a></article>
      <article class="news__item"><a href="#" class="news__link">
        <span class="news__date">2026.04.20</span>
        <span class="news__cat">MEDIA</span>
        <span class="news__title">FM802「Pop'n Roll」にREIRIEの2人がゲスト出演します</span>
      </a></article>

    <?php endif; ?>
  </div>

  <div class="section__more">
    <a href="<?php echo esc_url( get_post_type_archive_link( 'news' ) ); ?>" class="more-btn"><span>VIEW ALL NEWS</span></a>
  </div>
</section>
