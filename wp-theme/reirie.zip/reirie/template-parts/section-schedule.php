<?php
/**
 * Schedule Section
 *
 * @package REIRIE
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$schedule_query = new WP_Query( array(
	'post_type'      => 'schedule',
	'posts_per_page' => 6,
	'post_status'    => 'publish',
	'meta_key'       => 'schedule_date',
	'orderby'        => 'meta_value',
	'order'          => 'ASC',
) );
?>

<section class="section schedule" id="schedule">
  <div class="section__head">
    <span class="section__num">02 / Schedule</span>
    <h2 class="section__title">Schedule<span class="section__title-jp">スケジュール</span></h2>
  </div>

  <div class="schedule__list">
    <?php if ( $schedule_query->have_posts() ) : while ( $schedule_query->have_posts() ) : $schedule_query->the_post();
      $date_str  = reirie_field( 'schedule_date' );
      $venue     = reirie_field( 'schedule_venue' );
      $time      = reirie_field( 'schedule_time' );
      $detail    = reirie_field( 'schedule_link' );
      $highlight = reirie_field( 'schedule_highlight' );

      $ts        = $date_str ? strtotime( $date_str ) : 0;
      $day       = $ts ? date( 'd', $ts ) : '--';
      $month     = $ts ? strtoupper( date( 'M Y', $ts ) ) : '';
      $weekday   = $ts ? strtoupper( date( 'D', $ts ) ) : '';
    ?>
      <article class="schedule__item<?php echo $highlight ? ' highlight' : ''; ?>">
        <div class="schedule__date">
          <span class="day"><?php echo esc_html( $day ); ?></span>
          <span class="month"><?php echo esc_html( $month ); ?></span>
          <span class="weekday"><?php echo esc_html( $weekday ); ?></span>
        </div>
        <div class="schedule__body">
          <span class="schedule__cat"><?php echo esc_html( reirie_get_schedule_category() ); ?></span>
          <h3 class="schedule__title"><?php the_title(); ?></h3>
          <p class="schedule__meta">
            <?php if ( $venue ) : ?><span>📍 <?php echo esc_html( $venue ); ?></span><?php endif; ?>
            <?php if ( $time ) : ?><span>🕐 <?php echo esc_html( $time ); ?></span><?php endif; ?>
          </p>
        </div>
        <a href="<?php echo esc_url( $detail ? $detail : get_permalink() ); ?>" class="schedule__btn">Detail</a>
      </article>
    <?php endwhile; wp_reset_postdata(); else : ?>

      <article class="schedule__item">
        <div class="schedule__date"><span class="day">20</span><span class="month">MAY 2026</span><span class="weekday">WED</span></div>
        <div class="schedule__body">
          <span class="schedule__cat">RELEASE EVENT</span>
          <h3 class="schedule__title">2nd Single「Twinkle Heart」発売記念 ミニライブ&特典会</h3>
          <p class="schedule__meta"><span>📍 渋谷 TSUTAYA O-WEST</span><span>🕐 OPEN 18:00 / START 19:00</span></p>
        </div>
        <a href="#" class="schedule__btn">Detail</a>
      </article>
      <article class="schedule__item highlight">
        <div class="schedule__date"><span class="day">20</span><span class="month">JUL 2026</span><span class="weekday">SUN</span></div>
        <div class="schedule__body">
          <span class="schedule__cat">ONE-MAN</span>
          <h3 class="schedule__title">1st ONE-MAN LIVE「A Lovely Spring」</h3>
          <p class="schedule__meta"><span>📍 LINE CUBE SHIBUYA</span><span>🕐 OPEN 17:00 / START 18:00</span></p>
        </div>
        <a href="#" class="schedule__btn">Detail</a>
      </article>

    <?php endif; ?>
  </div>

  <div class="section__more">
    <a href="<?php echo esc_url( get_post_type_archive_link( 'schedule' ) ); ?>" class="more-btn"><span>VIEW ALL SCHEDULE</span></a>
  </div>
</section>
