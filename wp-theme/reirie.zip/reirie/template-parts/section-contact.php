<?php
/**
 * Contact Section
 *
 * Each card links to the custom contact page (template-contact.php)
 * with a specific ?type= query parameter that pre-selects the form type.
 *
 * @package REIRIE
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Mapping:
 *   FANCLUB  → fanmail  (ファンレター)
 *   PRESS    → press    (取材依頼)
 *   FAN MAIL → casting  (出演依頼)
 *
 * Each entry has its own customizer keys (reirie_contact_<key>_*),
 * but the URL is fixed to /contact/?type=<form-type>.
 */
$cards = array(
    'fanclub' => 'fanmail',
    'press'   => 'press',
    'fanmail' => 'casting',
);

// Resolve base URL of the contact page. Try to find a page using the
// custom template, otherwise fall back to /contact/.
$contact_base = home_url( '/contact/' );
$contact_pages = get_posts( array(
    'post_type'      => 'page',
    'meta_key'       => '_wp_page_template',
    'meta_value'     => 'page-templates/template-contact.php',
    'posts_per_page' => 1,
    'fields'         => 'ids',
) );
if ( ! empty( $contact_pages ) ) {
    $contact_base = get_permalink( $contact_pages[0] );
}
?>

<section class="section contact" id="contact">
  <div class="section__head">
    <span class="section__num">07 / Contact</span>
    <h2 class="section__title">Contact<span class="section__title-jp">お問い合わせ</span></h2>
  </div>

  <div class="contact__grid">
    <?php foreach ( $cards as $key => $form_type ) :
      $label = get_theme_mod( 'reirie_contact_' . $key . '_label' );
      $title = get_theme_mod( 'reirie_contact_' . $key . '_title' );
      $desc  = get_theme_mod( 'reirie_contact_' . $key . '_desc' );
      $url   = add_query_arg( 'type', $form_type, $contact_base );
    ?>
      <a href="<?php echo esc_url( $url ); ?>" class="contact__card" data-form-type="<?php echo esc_attr( $form_type ); ?>">
        <span class="contact__label"><?php echo esc_html( $label ); ?></span>
        <h3><?php echo esc_html( $title ); ?></h3>
        <p><?php echo esc_html( $desc ); ?></p>
        <span class="arrow">→</span>
      </a>
    <?php endforeach; ?>
  </div>
</section>
