<?php
/**
 * テンプレート用ヘルパー関数
 *
 * @package REIRIE
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SNS リンクを取得
 */
function reirie_get_sns_links() {
	return array(
		'twitter'   => array(
			'url'   => get_theme_mod( 'reirie_sns_twitter', '#' ),
			'label' => 'X (Twitter)',
			'icon'  => '<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
		),
		'instagram' => array(
			'url'   => get_theme_mod( 'reirie_sns_instagram', '#' ),
			'label' => 'Instagram',
			'icon'  => '<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M12 2.2c3.2 0 3.6 0 4.8.1 1.2.1 1.8.2 2.2.4.6.2 1 .5 1.4.9.4.4.7.9.9 1.4.2.4.4 1.1.4 2.2.1 1.2.1 1.6.1 4.8s0 3.6-.1 4.8c-.1 1.2-.2 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.9.7-1.4.9-.4.2-1.1.4-2.2.4-1.2.1-1.6.1-4.8.1s-3.6 0-4.8-.1c-1.2-.1-1.8-.2-2.2-.4-.6-.2-1-.5-1.4-.9-.4-.4-.7-.9-.9-1.4-.2-.4-.4-1.1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.8c.1-1.2.2-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.9-.7 1.4-.9.4-.2 1.1-.4 2.2-.4C8.4 2.2 8.8 2.2 12 2.2zm0 1.8c-3.1 0-3.5 0-4.7.1-1.1.1-1.7.2-2.1.4-.5.2-.9.4-1.3.8-.4.4-.6.8-.8 1.3-.2.4-.3 1-.4 2.1-.1 1.2-.1 1.6-.1 4.7s0 3.5.1 4.7c.1 1.1.2 1.7.4 2.1.2.5.4.9.8 1.3.4.4.8.6 1.3.8.4.2 1 .3 2.1.4 1.2.1 1.6.1 4.7.1s3.5 0 4.7-.1c1.1-.1 1.7-.2 2.1-.4.5-.2.9-.4 1.3-.8.4-.4.6-.8.8-1.3.2-.4.3-1 .4-2.1.1-1.2.1-1.6.1-4.7s0-3.5-.1-4.7c-.1-1.1-.2-1.7-.4-2.1-.2-.5-.4-.9-.8-1.3-.4-.4-.8-.6-1.3-.8-.4-.2-1-.3-2.1-.4C15.5 4 15.1 4 12 4zm0 3.1c2.7 0 4.9 2.2 4.9 4.9s-2.2 4.9-4.9 4.9-4.9-2.2-4.9-4.9 2.2-4.9 4.9-4.9zm0 8.1c1.8 0 3.2-1.4 3.2-3.2S13.8 8.8 12 8.8 8.8 10.2 8.8 12s1.4 3.2 3.2 3.2zm6.3-8.3c0 .6-.5 1.2-1.2 1.2s-1.2-.5-1.2-1.2.5-1.2 1.2-1.2 1.2.5 1.2 1.2z"/></svg>',
		),
		'tiktok'    => array(
			'url'   => get_theme_mod( 'reirie_sns_tiktok', '#' ),
			'label' => 'TikTok',
			'icon'  => '<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V8.7a8.16 8.16 0 0 0 4.77 1.52V6.83a4.85 4.85 0 0 1-1.84-.14z"/></svg>',
		),
		'youtube'   => array(
			'url'   => get_theme_mod( 'reirie_sns_youtube', '#' ),
			'label' => 'YouTube',
			'icon'  => '<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M23.5 6.2c-.3-1-1-1.8-2-2C19.7 3.7 12 3.7 12 3.7s-7.7 0-9.5.5c-1 .3-1.8 1-2 2C0 8 0 12 0 12s0 4 .5 5.8c.3 1 1 1.8 2 2 1.8.5 9.5.5 9.5.5s7.7 0 9.5-.5c1-.3 1.8-1 2-2 .5-1.8.5-5.8.5-5.8s0-4-.5-5.8zM9.6 15.6V8.4l6.4 3.6-6.4 3.6z"/></svg>',
		),
	);
}

/**
 * ACF get_field のラッパー（ACF未導入時は空文字を返す）
 */
function reirie_field( $name, $post_id = false, $default = '' ) {
	if ( function_exists( 'get_field' ) ) {
		$value = get_field( $name, $post_id );
		return ( $value === false || $value === null || $value === '' ) ? $default : $value;
	}
	// フォールバック：post_meta から取得
	if ( ! $post_id ) $post_id = get_the_ID();
	$value = get_post_meta( $post_id, $name, true );
	return ( $value === '' ) ? $default : $value;
}

/**
 * 日付フォーマット（Y.m.d）
 */
function reirie_format_date( $date_str, $format = 'Y.m.d' ) {
	if ( ! $date_str ) return '';
	$ts = strtotime( $date_str );
	if ( ! $ts ) return $date_str;
	return date_i18n( $format, $ts );
}

/**
 * News のカテゴリーラベル（最初の1個）を取得
 */
function reirie_get_news_category( $post_id = null ) {
	if ( ! $post_id ) $post_id = get_the_ID();
	$terms = get_the_terms( $post_id, 'news_category' );
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		return strtoupper( $terms[0]->name );
	}
	return 'INFO';
}

/**
 * Schedule のカテゴリーラベル
 */
function reirie_get_schedule_category( $post_id = null ) {
	if ( ! $post_id ) $post_id = get_the_ID();
	$terms = get_the_terms( $post_id, 'schedule_category' );
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		return strtoupper( $terms[0]->name );
	}
	return 'EVENT';
}

/**
 * グラデーションクラスを順送りで返す（ジャケット/動画サムネ用）
 */
function reirie_color_class( $index, $type = 'jacket' ) {
	$max = ( $type === 'thumb' ) ? 6 : 3;
	$num = ( $index % $max ) + 1;
	return $type . '-' . $num;
}
