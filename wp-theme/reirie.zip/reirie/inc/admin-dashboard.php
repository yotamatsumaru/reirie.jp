<?php
/**
 * REIRIE 管理ダッシュボードページ
 *
 * 管理画面トップに「REIRIE 設定」メニューを追加し、
 * ヒーロー / 各セクション / お問い合わせフォームへの導線を集約する。
 *
 * @package REIRIE
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 管理メニュー登録
 */
function reirie_admin_menu() {
	add_menu_page(
		'REIRIE 設定',
		'REIRIE 設定',
		'manage_options',
		'reirie-dashboard',
		'reirie_dashboard_page',
		'dashicons-heart',
		2
	);

	add_submenu_page(
		'reirie-dashboard',
		'ダッシュボード',
		'ダッシュボード',
		'manage_options',
		'reirie-dashboard',
		'reirie_dashboard_page'
	);

	add_submenu_page(
		'reirie-dashboard',
		'クイックヘルプ',
		'クイックヘルプ',
		'manage_options',
		'reirie-help',
		'reirie_help_page'
	);
}
add_action( 'admin_menu', 'reirie_admin_menu' );

/**
 * ダッシュボード本体
 */
function reirie_dashboard_page() {
	$customize_url = admin_url( 'customize.php' );
	?>
	<div class="wrap reirie-dashboard">
		<h1 style="display:flex;align-items:center;gap:12px;">
			<span style="font-size:32px;">🎀</span>
			<span>REIRIE サイト設定</span>
		</h1>
		<p style="font-size:15px;color:#666;margin:8px 0 24px;">
			サイトの各部分は、以下のメニューから編集できます。困ったら「クイックヘルプ」をご確認ください。
		</p>

		<style>
			.reirie-dash-grid {
				display: grid;
				grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
				gap: 16px;
				margin-top: 16px;
			}
			.reirie-dash-card {
				background: #fff;
				border: 1px solid #e5d5e0;
				border-radius: 12px;
				padding: 20px;
				box-shadow: 0 2px 8px rgba(255,126,182,0.08);
				transition: transform .15s ease, box-shadow .15s ease;
			}
			.reirie-dash-card:hover {
				transform: translateY(-2px);
				box-shadow: 0 6px 16px rgba(255,126,182,0.18);
			}
			.reirie-dash-card .icon {
				font-size: 28px;
				margin-bottom: 8px;
				display: block;
			}
			.reirie-dash-card h2 {
				font-size: 17px;
				margin: 0 0 6px;
				color: #c43a73;
			}
			.reirie-dash-card p {
				font-size: 13px;
				color: #666;
				margin: 0 0 12px;
				line-height: 1.6;
			}
			.reirie-dash-card .button {
				background: linear-gradient(135deg, #ff7eb6 0%, #b07aff 100%);
				color: #fff;
				border: none;
				padding: 8px 16px;
				border-radius: 20px;
				font-size: 13px;
				font-weight: bold;
				text-decoration: none;
				display: inline-block;
			}
			.reirie-dash-card .button:hover {
				color: #fff;
				opacity: .9;
			}
			.reirie-dash-section-title {
				font-size: 18px;
				color: #c43a73;
				margin: 32px 0 8px;
				padding-bottom: 6px;
				border-bottom: 2px solid #ffd6e8;
			}
			.reirie-dash-status {
				background: #fff5f9;
				border-left: 4px solid #ff7eb6;
				padding: 14px 18px;
				border-radius: 4px;
				margin: 16px 0 24px;
			}
			.reirie-dash-status strong { color: #c43a73; }
		</style>

		<?php
		// セットアップ進捗チェック
		$has_home    = (bool) get_option( 'page_on_front' );
		$has_member  = (int) wp_count_posts( 'member' )->publish;
		$has_news    = (int) wp_count_posts( 'news' )->publish;
		$has_disco   = (int) wp_count_posts( 'discography' )->publish;
		$has_contact = get_posts( array(
			'post_type'      => 'page',
			'meta_key'       => '_wp_page_template',
			'meta_value'     => 'page-templates/template-contact.php',
			'posts_per_page' => 1,
			'fields'         => 'ids',
		) );
		?>

		<div class="reirie-dash-status">
			<strong>セットアップ進捗</strong><br>
			<?php echo $has_home ? '✅' : '⚠️'; ?> トップページ設定<?php echo $has_home ? '（OK）' : '（未設定 — <a href="' . esc_url( admin_url( 'options-reading.php' ) ) . '">設定→表示設定</a>）'; ?> /
			<?php echo $has_member ? '✅' : '⚠️'; ?> メンバー登録 <?php echo $has_member; ?>件 /
			<?php echo $has_news ? '✅' : '⚠️'; ?> News <?php echo $has_news; ?>件 /
			<?php echo $has_disco ? '✅' : '⚠️'; ?> 作品 <?php echo $has_disco; ?>件 /
			<?php echo ! empty( $has_contact ) ? '✅' : '⚠️'; ?> お問い合わせページ
		</div>

		<h2 class="reirie-dash-section-title">🎬 サイト全体のデザイン</h2>
		<div class="reirie-dash-grid">
			<div class="reirie-dash-card">
				<span class="icon">🎥</span>
				<h2>ヒーロービジョン</h2>
				<p>トップ画面の動画・タイトル・キャッチコピー・スライドテロップを編集します。</p>
				<a class="button" href="<?php echo esc_url( add_query_arg( array( 'autofocus[section]' => 'reirie_hero' ), $customize_url ) ); ?>">編集する →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">📱</span>
				<h2>SNSリンク</h2>
				<p>X / Instagram / TikTok / YouTube のURLを設定します。ヘッダー・フッターに反映されます。</p>
				<a class="button" href="<?php echo esc_url( add_query_arg( array( 'autofocus[section]' => 'reirie_sns' ), $customize_url ) ); ?>">編集する →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">🌸</span>
				<h2>ロゴ・サイト基本情報</h2>
				<p>サイトロゴ・タイトル・ファビコンの差し替えはこちら。</p>
				<a class="button" href="<?php echo esc_url( add_query_arg( array( 'autofocus[section]' => 'title_tagline' ), $customize_url ) ); ?>">編集する →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">🦶</span>
				<h2>フッター</h2>
				<p>コピーライト表記・サブタイトルを編集します。</p>
				<a class="button" href="<?php echo esc_url( add_query_arg( array( 'autofocus[section]' => 'reirie_footer' ), $customize_url ) ); ?>">編集する →</a>
			</div>
		</div>

		<h2 class="reirie-dash-section-title">📝 コンテンツの登録</h2>
		<div class="reirie-dash-grid">
			<div class="reirie-dash-card">
				<span class="icon">👯</span>
				<h2>メンバー（アーティスト情報）</h2>
				<p>Rei・Rie のプロフィール、メンバーカラー、SNS、メッセージなどを編集します。</p>
				<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=member' ) ); ?>">一覧へ →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">📢</span>
				<h2>お知らせ（News）</h2>
				<p>最新情報・告知を投稿します。</p>
				<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=news' ) ); ?>">一覧へ →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">📅</span>
				<h2>スケジュール</h2>
				<p>ライブ・イベント情報を登録します。</p>
				<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=schedule' ) ); ?>">一覧へ →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">💿</span>
				<h2>ディスコグラフィ</h2>
				<p>シングル・アルバム・ジャケット・配信リンクを登録します。</p>
				<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=discography' ) ); ?>">一覧へ →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">🎬</span>
				<h2>動画（Movie）</h2>
				<p>MV・特典映像のYouTube URLを登録します。</p>
				<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=movie' ) ); ?>">一覧へ →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">🛍️</span>
				<h2>グッズ</h2>
				<p>物販グッズの画像・価格・販売ページのURLを登録します。</p>
				<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=goods' ) ); ?>">一覧へ →</a>
			</div>
		</div>

		<h2 class="reirie-dash-section-title">✉️ お問い合わせ</h2>
		<div class="reirie-dash-grid">
			<div class="reirie-dash-card">
				<span class="icon">📨</span>
				<h2>受信メッセージ</h2>
				<p>フォームから送信されたお問い合わせを確認できます。</p>
				<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=contact_msg' ) ); ?>">一覧へ →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">⚙️</span>
				<h2>お問い合わせカード</h2>
				<p>Contact セクションの3枚のカード（FANCLUB / PRESS / FAN MAIL）の文言を編集。</p>
				<a class="button" href="<?php echo esc_url( add_query_arg( array( 'autofocus[section]' => 'reirie_contact' ), $customize_url ) ); ?>">編集する →</a>
			</div>
			<div class="reirie-dash-card">
				<span class="icon">📧</span>
				<h2>フォーム設定</h2>
				<p>通知先メール・説明文・プライバシーポリシーURLを設定します。</p>
				<a class="button" href="<?php echo esc_url( add_query_arg( array( 'autofocus[section]' => 'reirie_contact_form' ), $customize_url ) ); ?>">編集する →</a>
			</div>
		</div>

		<h2 class="reirie-dash-section-title">🎨 一括編集</h2>
		<div class="reirie-dash-grid">
			<div class="reirie-dash-card" style="grid-column: span 2;">
				<span class="icon">🎛️</span>
				<h2>カスタマイザーですべて編集</h2>
				<p>ライブプレビューを見ながら、ヒーロー・SNS・カード・フォームをまとめて編集できます。</p>
				<a class="button" href="<?php echo esc_url( $customize_url ); ?>">カスタマイザーを開く →</a>
			</div>
		</div>
	</div>
	<?php
}

/**
 * ヘルプページ
 */
function reirie_help_page() {
	?>
	<div class="wrap">
		<h1>🆘 REIRIEテーマ クイックヘルプ</h1>

		<style>
			.reirie-help { max-width: 860px; }
			.reirie-help h2 { color: #c43a73; border-bottom: 2px solid #ffd6e8; padding-bottom: 6px; margin-top: 32px; }
			.reirie-help h3 { color: #b07aff; margin-top: 22px; }
			.reirie-help .qa { background: #fff5f9; border-left: 4px solid #ff7eb6; padding: 12px 16px; border-radius: 4px; margin: 12px 0; }
			.reirie-help .qa strong { color: #c43a73; }
			.reirie-help table { background: #fff; border-collapse: collapse; margin: 12px 0; }
			.reirie-help table th { background: #ffd6e8; padding: 8px 12px; text-align: left; }
			.reirie-help table td { padding: 8px 12px; border-bottom: 1px solid #f3e1eb; }
		</style>

		<div class="reirie-help">

			<h2>🌟 はじめての方へ</h2>
			<p>このテーマは、REIRIEオフィシャルサイトを管理画面から簡単に更新できるよう設計されています。<br>
			まずは <strong>「REIRIE設定 → ダッシュボード」</strong> から各機能にアクセスしてみてください。</p>

			<h2>📍 編集場所マップ</h2>
			<table class="widefat">
				<thead><tr><th>編集したい場所</th><th>編集メニュー</th></tr></thead>
				<tbody>
					<tr><td>トップの背景動画・タイトル</td><td>外観 → カスタマイズ → REIRIE：ヒーロービジョン</td></tr>
					<tr><td>SNSアイコンのリンク先</td><td>外観 → カスタマイズ → REIRIE：SNSリンク</td></tr>
					<tr><td>ロゴ画像</td><td>外観 → カスタマイズ → サイト基本情報</td></tr>
					<tr><td>News（お知らせ）</td><td>左メニュー → News</td></tr>
					<tr><td>ライブ・イベント</td><td>左メニュー → Schedule</td></tr>
					<tr><td>シングル・アルバム</td><td>左メニュー → Discography</td></tr>
					<tr><td>MV・動画</td><td>左メニュー → Movie</td></tr>
					<tr><td>メンバープロフィール</td><td>左メニュー → Member</td></tr>
					<tr><td>グッズ</td><td>左メニュー → Goods</td></tr>
					<tr><td>お問い合わせカード文言</td><td>外観 → カスタマイズ → REIRIE：お問い合わせカード</td></tr>
					<tr><td>お問い合わせフォーム設定</td><td>外観 → カスタマイズ → REIRIE：お問い合わせフォーム</td></tr>
					<tr><td>受信したお問い合わせ</td><td>左メニュー → お問い合わせ</td></tr>
					<tr><td>フッターのコピーライト</td><td>外観 → カスタマイズ → REIRIE：フッター</td></tr>
				</tbody>
			</table>

			<h2>❓ よくある質問</h2>

			<div class="qa">
				<strong>Q. ヒーローの動画を変えたい</strong><br>
				外観 → カスタマイズ → REIRIE：ヒーロービジョン → ヒーロー背景動画 から差し替え。MP4・10〜15秒・5MB以下推奨。
			</div>

			<div class="qa">
				<strong>Q. メンバーの並び順を変えたい</strong><br>
				左メニュー Member → 編集画面右の「ページ属性」→「順序」の数字を変更（小さい数字が左）。
			</div>

			<div class="qa">
				<strong>Q. シングルが新着扱いされない</strong><br>
				Discographyの編集画面下部「Discography 詳細」で<strong>「NEWバッジを表示」</strong>にチェック。
			</div>

			<div class="qa">
				<strong>Q. パーマリンクが404になる</strong><br>
				設定 → パーマリンク を開いて、何もせず「変更を保存」を押してください。
			</div>

			<div class="qa">
				<strong>Q. お問い合わせフォームを表示したい</strong><br>
				固定ページを新規追加 → ページ属性のテンプレートで <strong>「REIRIE お問い合わせフォーム」</strong> を選択 → スラッグを <code>contact</code> に設定。
			</div>

			<div class="qa">
				<strong>Q. 通知メールが届かない</strong><br>
				サーバーのメール送信設定（SMTP）が必要な場合があります。WordPress標準の <code>wp_mail()</code> を使用しているため、必要に応じて WP Mail SMTP プラグイン等の導入をご検討ください。
			</div>

			<h2>🔗 サポート</h2>
			<p>不明点はテーマ制作担当までお問い合わせください 🌸</p>
		</div>
	</div>
	<?php
}
