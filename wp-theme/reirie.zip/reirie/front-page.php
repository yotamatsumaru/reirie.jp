<?php
/**
 * フロントページ（トップページ）テンプレート
 *
 * @package REIRIE
 */

get_header(); ?>

<?php get_template_part( 'template-parts/section', 'hero' ); ?>
<?php get_template_part( 'template-parts/section', 'news' ); ?>
<?php get_template_part( 'template-parts/section', 'schedule' ); ?>
<?php get_template_part( 'template-parts/section', 'discography' ); ?>
<?php get_template_part( 'template-parts/section', 'movie' ); ?>
<?php get_template_part( 'template-parts/section', 'profile' ); ?>
<?php get_template_part( 'template-parts/section', 'goods' ); ?>
<?php get_template_part( 'template-parts/section', 'contact' ); ?>

<?php get_footer(); ?>
