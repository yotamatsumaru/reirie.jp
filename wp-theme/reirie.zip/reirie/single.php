<?php
/**
 * 単一記事テンプレート（共通）
 *
 * @package REIRIE
 */

get_header(); ?>

<main class="section single-page">
  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <article class="single-article" style="max-width:880px;margin:0 auto;">
      <div class="section__head">
        <span class="section__num"><?php echo esc_html( strtoupper( get_post_type() ) ); ?></span>
        <h2 class="section__title" style="font-size:clamp(32px,5vw,56px);"><?php the_title(); ?></h2>
        <p style="margin-top:12px;font-family:var(--serif);letter-spacing:.2em;color:var(--pink-deep);">
          <?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?>
        </p>
      </div>

      <?php if ( has_post_thumbnail() ) : ?>
        <div style="margin-bottom:40px;border-radius:18px;overflow:hidden;box-shadow:0 12px 32px rgba(255,126,182,.18);">
          <?php the_post_thumbnail( 'large', array( 'style' => 'width:100%;height:auto;display:block;' ) ); ?>
        </div>
      <?php endif; ?>

      <div class="single-content" style="font-size:15px;line-height:1.95;">
        <?php the_content(); ?>
      </div>

      <div style="text-align:center;margin-top:60px;">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="more-btn"><span>BACK TO TOP</span></a>
      </div>
    </article>
  <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>
